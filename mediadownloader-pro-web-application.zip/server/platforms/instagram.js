/**
 * Instagram platform handler
 */

const infoCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getMediaId(url) {
  const patterns = [
    /instagram\.com\/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/,
    /instagram\.com\/stories\/[\w.-]+\/(\d+)/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return `ig_${Buffer.from(url).toString('base64').slice(0, 8)}`;
}

async function fetchInfo(url) {
  const mediaId = getMediaId(url);

  const cached = infoCache.get(mediaId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  const videoInfo = {
    id: `ig_${mediaId}`,
    title: `Instagram Post (${mediaId})`,
    thumbnail: `https://picsum.photos/seed/insta-${mediaId}/1080/1080`,
    duration: Math.floor(Math.random() * 90) + 5, // 5-95 seconds
    qualities: [
      { label: '360p', value: '360', size: '~4 MB', type: 'video' },
      { label: '720p (HD)', value: '720', size: '~10 MB', type: 'video' },
      { label: 'MP3 Audio', value: 'mp3', size: '~1.5 MB', type: 'audio' },
    ],
  };

  infoCache.set(mediaId, { data: videoInfo, timestamp: Date.now() });
  return videoInfo;
}

export const instagramHandler = { fetchInfo, getMediaId };
