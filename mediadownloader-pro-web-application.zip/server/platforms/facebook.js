/**
 * Facebook platform handler
 */

const infoCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getVideoId(url) {
  const patterns = [
    /facebook\.com\/[\w.-]+\/videos\/(\d+)/,
    /facebook\.com\/watch\/?\?v=(\d+)/,
    /fb\.watch\/([a-zA-Z0-9]+)/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return `fb_${Buffer.from(url).toString('base64').slice(0, 8)}`;
}

async function fetchInfo(url) {
  const videoId = getVideoId(url);

  const cached = infoCache.get(videoId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  const videoInfo = {
    id: `fb_${videoId}`,
    title: `Facebook Video (${videoId})`,
    thumbnail: `https://picsum.photos/seed/fb-${videoId}/1280/720`,
    duration: Math.floor(Math.random() * 3600) + 30, // 30 sec - 1 hour
    qualities: [
      { label: '360p', value: '360', size: '~30 MB', type: 'video' },
      { label: '720p (HD)', value: '720', size: '~90 MB', type: 'video' },
      { label: '1080p (Full HD)', value: '1080', size: '~180 MB', type: 'video' },
      { label: 'MP3 Audio', value: 'mp3', size: '~10 MB', type: 'audio' },
    ],
  };

  infoCache.set(videoId, { data: videoInfo, timestamp: Date.now() });
  return videoInfo;
}

export const facebookHandler = { fetchInfo, getVideoId };
