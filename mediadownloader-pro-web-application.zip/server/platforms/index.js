import { youtubeHandler } from './youtube.js';
import { tiktokHandler } from './tiktok.js';
import { instagramHandler } from './instagram.js';
import { facebookHandler } from './facebook.js';
import { twitterHandler } from './twitter.js';

const SUPPORTED_PLATFORMS = {
  youtube: {
    domains: ['youtube.com', 'youtu.be'],
    handler: youtubeHandler,
    name: 'YouTube',
    color: '#FF0000',
  },
  tiktok: {
    domains: ['tiktok.com'],
    handler: tiktokHandler,
    name: 'TikTok',
    color: '#000000',
  },
  instagram: {
    domains: ['instagram.com'],
    handler: instagramHandler,
    name: 'Instagram',
    color: '#E4405F',
  },
  facebook: {
    domains: ['facebook.com', 'fb.watch'],
    handler: facebookHandler,
    name: 'Facebook',
    color: '#1877F2',
  },
  twitter: {
    domains: ['twitter.com', 'x.com'],
    handler: twitterHandler,
    name: 'Twitter',
    color: '#1DA1F2',
  },
};

export function detectPlatform(url) {
  const lowerUrl = url.toLowerCase();

  for (const [key, platform] of Object.entries(SUPPORTED_PLATFORMS)) {
    if (platform.domains.some(domain => lowerUrl.includes(domain))) {
      return { key, ...platform };
    }
  }

  return null;
}

export async function processVideo(url) {
  const platform = detectPlatform(url);

  if (!platform) {
    throw new Error('Unsupported platform');
  }

  const videoInfo = await platform.handler.fetchInfo(url);

  return {
    id: videoInfo.id,
    title: videoInfo.title,
    thumbnail: videoInfo.thumbnail,
    duration: videoInfo.duration,
    platform: platform.name,
    platformKey: platform.key,
    url,
    qualities: videoInfo.qualities,
  };
}
