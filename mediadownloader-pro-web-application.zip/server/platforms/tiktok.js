/**
 * TikTok platform handler
 */

const infoCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getVideoId(url) {
  const match = url.match(/tiktok\.com\/@[\w.-]+\/video\/(\d+)/);
  return match ? match[1] : `tt_${Buffer.from(url).toString('base64').slice(0, 8)}`;
}

async function fetchInfo(url) {
  const videoId = getVideoId(url);

  const cached = infoCache.get(videoId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  // In production, fetch from TikTok's API or use scraping
  const videoInfo = {
    id: `tt_${videoId}`,
    title: `TikTok Video (${videoId})`,
    thumbnail: `https://picsum.photos/seed/tiktok-${videoId}/720/1280`,
    duration: Math.floor(Math.random() * 60) + 15, // 15-75 seconds
    qualities: [
      { label: '360p', value: '360', size: '~5 MB', type: 'video' },
      { label: '720p (HD)', value: '720', size: '~12 MB', type: 'video' },
      { label: 'MP3 Audio', value: 'mp3', size: '~2 MB', type: 'audio' },
    ],
  };

  infoCache.set(videoId, { data: videoInfo, timestamp: Date.now() });
  return videoInfo;
}

export const tiktokHandler = { fetchInfo, getVideoId };
