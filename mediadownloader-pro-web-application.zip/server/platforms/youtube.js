import axios from 'axios';

/**
 * YouTube platform handler
 * In production, this would use youtube-dl or yt-dlp or the YouTube Data API
 */

// Cache for fetched video info to improve performance
const infoCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

function getVideoId(url) {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

async function fetchInfo(url) {
  const videoId = getVideoId(url);
  if (!videoId) {
    throw new Error('Invalid YouTube URL');
  }

  // Check cache
  const cached = infoCache.get(videoId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  // In production, this would call the YouTube Data API
  // or use yt-dlp to extract real video info
  // For now, we return structured mock data

  const videoInfo = {
    id: `yt_${videoId}`,
    title: `YouTube Video (${videoId})`,
    thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
    duration: Math.floor(Math.random() * 1800) + 60, // 1-30 minutes
    qualities: [
      { label: '144p (Low)', value: '144', size: '~15 MB', type: 'video' },
      { label: '360p', value: '360', size: '~45 MB', type: 'video' },
      { label: '480p', value: '480', size: '~80 MB', type: 'video' },
      { label: '720p (HD)', value: '720', size: '~150 MB', type: 'video' },
      { label: '1080p (Full HD)', value: '1080', size: '~280 MB', type: 'video' },
      { label: '2160p (4K)', value: '2160', size: '~800 MB', type: 'video' },
      { label: 'MP3 Audio', value: 'mp3', size: '~8 MB', type: 'audio' },
    ],
  };

  // Cache the result
  infoCache.set(videoId, { data: videoInfo, timestamp: Date.now() });

  return videoInfo;
}

export const youtubeHandler = {
  fetchInfo,
  getVideoId,
};
