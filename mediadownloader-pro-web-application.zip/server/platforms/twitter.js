/**
 * Twitter/X platform handler
 */

const infoCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getTweetId(url) {
  const patterns = [
    /(?:twitter\.com|x\.com)\/\w+\/status\/(\d+)/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return `tw_${Buffer.from(url).toString('base64').slice(0, 8)}`;
}

async function fetchInfo(url) {
  const tweetId = getTweetId(url);

  const cached = infoCache.get(tweetId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  const videoInfo = {
    id: `tw_${tweetId}`,
    title: `Twitter/X Post (${tweetId})`,
    thumbnail: `https://picsum.photos/seed/tw-${tweetId}/1280/720`,
    duration: Math.floor(Math.random() * 180) + 10, // 10 sec - 3 min
    qualities: [
      { label: '360p', value: '360', size: '~6 MB', type: 'video' },
      { label: '720p (HD)', value: '720', size: '~15 MB', type: 'video' },
      { label: 'MP3 Audio', value: 'mp3', size: '~3 MB', type: 'audio' },
    ],
  };

  infoCache.set(tweetId, { data: videoInfo, timestamp: Date.now() });
  return videoInfo;
}

export const twitterHandler = { fetchInfo, getTweetId };
