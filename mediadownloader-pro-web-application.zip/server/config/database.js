import mongoose from 'mongoose';

let isConnected = false;

export async function connectDatabase() {
  if (isConnected) {
    console.log('📊 Using existing database connection');
    return;
  }

  const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/mediadownloader';

  try {
    const db = await mongoose.connect(MONGODB_URI, {
      // Mongoose 8+ uses these defaults
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });

    isConnected = !!db.connections[0].readyState;
    console.log(`📊 Connected to MongoDB: ${db.connection.host}`);

    // Handle connection events
    mongoose.connection.on('error', (err) => {
      console.error('📊 MongoDB connection error:', err);
      isConnected = false;
    });

    mongoose.connection.on('disconnected', () => {
      console.log('📊 MongoDB disconnected');
      isConnected = false;
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
      await mongoose.connection.close();
      console.log('📊 MongoDB connection closed through app termination');
      process.exit(0);
    });
  } catch (error) {
    console.error('📊 MongoDB connection failed:', error.message);
    console.log('📊 Running in offline mode - using in-memory storage');
    isConnected = false;
  }
}

export function getConnectionStatus() {
  return isConnected;
}
