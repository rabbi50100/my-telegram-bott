const SUPPORTED_DOMAINS = [
  'youtube.com',
  'youtu.be',
  'tiktok.com',
  'instagram.com',
  'facebook.com',
  'fb.watch',
  'twitter.com',
  'x.com',
];

export function validateVideoUrl(req, res, next) {
  const { url } = req.body;

  if (!url || typeof url !== 'string') {
    return res.status(400).json({
      error: 'Invalid request',
      message: 'URL is required',
    });
  }

  const trimmedUrl = url.trim();

  // Validate URL format
  try {
    const parsed = new URL(trimmedUrl);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      throw new Error('Invalid protocol');
    }
  } catch {
    return res.status(400).json({
      error: 'Invalid URL',
      message: 'Please provide a valid HTTP or HTTPS URL',
    });
  }

  // Check if domain is supported
  const isSupported = SUPPORTED_DOMAINS.some(domain =>
    trimmedUrl.toLowerCase().includes(domain)
  );

  if (!isSupported) {
    return res.status(400).json({
      error: 'Unsupported platform',
      message: 'This platform is not currently supported',
    });
  }

  req.validatedUrl = trimmedUrl;
  next();
}
