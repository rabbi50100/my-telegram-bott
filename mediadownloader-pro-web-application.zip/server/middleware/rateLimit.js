import rateLimit from 'express-rate-limit';

// Stricter rate limit for video processing endpoints
export const videoRateLimit = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 requests per minute
  message: {
    error: 'Rate limit exceeded',
    message: 'Too many video processing requests. Please wait a moment.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Rate limit for auth endpoints
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per 15 minutes
  message: {
    error: 'Rate limit exceeded',
    message: 'Too many login attempts. Please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});
