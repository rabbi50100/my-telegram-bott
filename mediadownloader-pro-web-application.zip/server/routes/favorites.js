import { Router } from 'express';
import { authenticateToken } from '../middleware/auth.js';

export const favoritesRouter = Router();

// In-memory storage (replace with MongoDB in production)
const userFavorites = new Map();

// GET /api/favorites - Get favorites
favoritesRouter.get('/', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const favorites = userFavorites.get(userId) || [];

    // Sort by most recent first
    favorites.sort((a, b) => b.timestamp - a.timestamp);

    res.json({
      success: true,
      data: favorites,
      total: favorites.length,
    });
  } catch (error) {
    console.error('Favorites fetch error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to fetch favorites',
    });
  }
});

// POST /api/favorites - Add to favorites
favoritesRouter.post('/', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const { videoId, title, thumbnail, platform, url } = req.body;

    if (!videoId || !title) {
      return res.status(400).json({
        error: 'Validation error',
        message: 'videoId and title are required',
      });
    }

    const favorites = userFavorites.get(userId) || [];

    // Check if already favorited
    if (favorites.some(f => f.videoId === videoId)) {
      return res.status(409).json({
        error: 'Conflict',
        message: 'Video is already in favorites',
      });
    }

    const favoriteItem = {
      id: `fav_${Date.now()}`,
      videoId,
      title,
      thumbnail: thumbnail || '',
      platform: platform || 'Unknown',
      url: url || '',
      timestamp: Date.now(),
    };

    favorites.unshift(favoriteItem);
    userFavorites.set(userId, favorites);

    res.status(201).json({
      success: true,
      data: favoriteItem,
    });
  } catch (error) {
    console.error('Favorites add error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to add to favorites',
    });
  }
});

// DELETE /api/favorites/:videoId - Remove from favorites
favoritesRouter.delete('/:videoId', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const { videoId } = req.params;

    const favorites = userFavorites.get(userId) || [];
    const filtered = favorites.filter(f => f.videoId !== videoId);
    userFavorites.set(userId, filtered);

    res.json({
      success: true,
      message: 'Removed from favorites',
    });
  } catch (error) {
    console.error('Favorites remove error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to remove from favorites',
    });
  }
});

// GET /api/favorites/check/:videoId - Check if video is favorited
favoritesRouter.get('/check/:videoId', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const { videoId } = req.params;

    const favorites = userFavorites.get(userId) || [];
    const isFav = favorites.some(f => f.videoId === videoId);

    res.json({
      success: true,
      data: { isFavorite: isFav },
    });
  } catch (error) {
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to check favorite status',
    });
  }
});
