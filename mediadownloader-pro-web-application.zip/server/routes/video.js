import { Router } from 'express';
import { validateVideoUrl } from '../middleware/validateUrl.js';
import { videoRateLimit } from '../middleware/rateLimit.js';
import { processVideo } from '../platforms/index.js';

export const videoRouter = Router();

// POST /api/video/info - Get video metadata
videoRouter.post('/info', videoRateLimit, validateVideoUrl, async (req, res) => {
  try {
    const { url } = req.body;
    const videoInfo = await processVideo(url);

    res.json({
      success: true,
      data: videoInfo,
    });
  } catch (error) {
    console.error('Video processing error:', error.message);

    if (error.message === 'Unsupported platform') {
      return res.status(400).json({
        success: false,
        error: 'Unsupported platform',
        message: 'This platform is not currently supported',
      });
    }

    res.status(500).json({
      success: false,
      error: 'Processing failed',
      message: 'Failed to process video. Please try again.',
    });
  }
});

// GET /api/video/download/:videoId/:quality - Generate download link
videoRouter.get('/download/:videoId/:quality', async (req, res) => {
  try {
    const { videoId, quality } = req.params;
    const type = quality === 'mp3' ? 'audio' : 'video';

    // In production, this would generate a signed URL or proxy the download
    const downloadUrl = `https://cdn.mediadownloader.pro/download/${videoId}/${quality}.${type === 'audio' ? 'mp3' : 'mp4'}`;

    res.json({
      success: true,
      data: {
        downloadUrl,
        videoId,
        quality,
        type,
        expiresIn: '1 hour',
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Download failed',
      message: 'Failed to generate download link',
    });
  }
});

// POST /api/video/track - Track download
videoRouter.post('/track', async (req, res) => {
  try {
    const { videoId, quality, type } = req.body;

    // In production, this would log to database
    console.log(`Download tracked: ${videoId} - ${quality} (${type})`);

    res.json({
      success: true,
      message: 'Download tracked',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Tracking failed',
    });
  }
});
