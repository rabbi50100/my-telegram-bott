import { Router } from 'express';
import { authenticateToken } from '../middleware/auth.js';

export const historyRouter = Router();

// In-memory storage (replace with MongoDB in production)
const userHistory = new Map();

// GET /api/history - Get download history
historyRouter.get('/', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const history = userHistory.get(userId) || [];

    // Sort by most recent first
    history.sort((a, b) => b.timestamp - a.timestamp);

    res.json({
      success: true,
      data: history.slice(0, 50), // Return last 50 items
      total: history.length,
    });
  } catch (error) {
    console.error('History fetch error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to fetch history',
    });
  }
});

// POST /api/history - Add to history
historyRouter.post('/', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const { videoId, title, thumbnail, quality, platform, type } = req.body;

    if (!videoId || !title) {
      return res.status(400).json({
        error: 'Validation error',
        message: 'videoId and title are required',
      });
    }

    const historyItem = {
      id: `dl_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      videoId,
      title,
      thumbnail,
      quality,
      platform,
      type: type || 'video',
      timestamp: Date.now(),
    };

    const history = userHistory.get(userId) || [];
    history.unshift(historyItem);
    userHistory.set(userId, history);

    res.status(201).json({
      success: true,
      data: historyItem,
    });
  } catch (error) {
    console.error('History add error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to add to history',
    });
  }
});

// DELETE /api/history - Clear history
historyRouter.delete('/', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    userHistory.set(userId, []);

    res.json({
      success: true,
      message: 'History cleared',
    });
  } catch (error) {
    console.error('History clear error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to clear history',
    });
  }
});

// DELETE /api/history/:id - Remove specific history item
historyRouter.delete('/:id', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const history = userHistory.get(userId) || [];
    const filtered = history.filter(item => item.id !== id);
    userHistory.set(userId, filtered);

    res.json({
      success: true,
      message: 'History item removed',
    });
  } catch (error) {
    console.error('History remove error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'Failed to remove history item',
    });
  }
});
