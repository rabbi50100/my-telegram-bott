import mongoose from 'mongoose';

const historySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  videoId: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters'],
  },
  thumbnail: {
    type: String,
    default: '',
  },
  quality: {
    type: String,
    required: true,
  },
  platform: {
    type: String,
    required: true,
    enum: ['YouTube', 'TikTok', 'Instagram', 'Facebook', 'Twitter'],
  },
  type: {
    type: String,
    enum: ['video', 'audio'],
    default: 'video',
  },
  downloadedAt: {
    type: Date,
    default: Date.now,
  },
});

// Index for efficient querying
historySchema.index({ userId: 1, downloadedAt: -1 });

// Limit history to 100 entries per user
historySchema.statics.addWithLimit = async function (userId, data) {
  const History = this;
  const history = new History({ userId, ...data });
  await history.save();

  // Count and remove excess entries
  const count = await History.countDocuments({ userId });
  if (count > 100) {
    const oldest = await History.find({ userId })
      .sort({ downloadedAt: 1 })
      .limit(count - 100);
    const idsToRemove = oldest.map(doc => doc._id);
    await History.deleteMany({ _id: { $in: idsToRemove } });
  }

  return history;
};

export const History = mongoose.model('History', historySchema);
