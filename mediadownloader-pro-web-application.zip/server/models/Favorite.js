import mongoose from 'mongoose';

const favoriteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  videoId: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters'],
  },
  thumbnail: {
    type: String,
    default: '',
  },
  platform: {
    type: String,
    required: true,
    enum: ['YouTube', 'TikTok', 'Instagram', 'Facebook', 'Twitter'],
  },
  url: {
    type: String,
    required: true,
  },
  addedAt: {
    type: Date,
    default: Date.now,
  },
});

// Ensure a user can't favorite the same video twice
favoriteSchema.index({ userId: 1, videoId: 1 }, { unique: true });

// Index for efficient querying
favoriteSchema.index({ userId: 1, addedAt: -1 });

export const Favorite = mongoose.model('Favorite', favoriteSchema);
