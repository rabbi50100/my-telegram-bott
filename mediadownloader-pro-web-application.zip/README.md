# MediaDownloader Pro

A professional, modern web application for downloading videos and audio from popular social media platforms.

## Features

### Core
- **Multi-Platform Support**: YouTube, TikTok, Instagram, Facebook, Twitter/X
- **Multiple Qualities**: 144p to 4K video + MP3 audio extraction
- **Fast Processing**: Parallel downloading with caching system
- **Metadata Display**: Title, thumbnail, duration, file sizes

### User System
- User registration & authentication (JWT-based)
- Download history tracking
- Favorites/watchlist system

### UX
- **Dark Mode**: Modern dark interface by default
- **Responsive**: Mobile-first design with Tailwind CSS
- **Multi-language**: English & Bangla (বাংলা) support
- **Smooth Animations**: Loading states, transitions, micro-interactions
- **Toast Notifications**: Real-time feedback for actions

### Security
- Rate limiting on all API endpoints
- URL validation & sanitization
- Password hashing with bcrypt (12 rounds)
- JWT token-based authentication

## Tech Stack

### Frontend
- **React 19** + **TypeScript**
- **Vite** (fast builds)
- **Tailwind CSS v4** (utility-first CSS)
- **React Router DOM** (client-side routing)
- **Lucide React** (icons)
- **React Hot Toast** (notifications)

### Backend
- **Node.js** + **Express** (REST API)
- **MongoDB** + **Mongoose** (database)
- **JWT** (authentication)
- **bcryptjs** (password hashing)
- **express-rate-limit** (rate limiting)

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- MongoDB (optional - falls back to in-memory storage)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/mediadownloader-pro.git
   cd mediadownloader-pro
   ```

2. **Install frontend dependencies**
   ```bash
   npm install
   ```

3. **Install backend dependencies**
   ```bash
   cd server
   npm install
   cd ..
   ```

4. **Configure environment**
   ```bash
   cp server/.env.example server/.env
   # Edit server/.env with your settings
   ```

5. **Start the backend server**
   ```bash
   cd server
   npm run dev
   ```

6. **Start the frontend** (in a new terminal)
   ```bash
   npm run dev
   ```

7. **Build for production**
   ```bash
   npm run build
   ```

## Project Structure

```
mediadownloader-pro/
├── index.html              # Entry HTML
├── vite.config.ts          # Vite configuration
├── package.json            # Frontend dependencies
├── tsconfig.json           # TypeScript configuration
│
├── src/                    # Frontend source
│   ├── main.tsx            # React entry point
│   ├── App.tsx             # Root component with routing
│   ├── index.css           # Global styles (Tailwind v4)
│   │
│   ├── components/         # React components
│   │   ├── Header.tsx         # Navigation header
│   │   ├── HeroSection.tsx    # URL input & search
│   │   ├── VideoCard.tsx      # Video metadata & downloads
│   │   ├── AuthModal.tsx      # Login/Signup modal
│   │   ├── HistoryPage.tsx    # Download history
│   │   ├── FavoritesPage.tsx  # Favorites list
│   │   └── Footer.tsx         # Page footer
│   │
│   ├── context/            # React context providers
│   │   ├── AuthContext.tsx     # Authentication state
│   │   └── LanguageContext.tsx # Multi-language state
│   │
│   ├── i18n/               # Internationalization
│   │   ├── index.ts           # Translation helper
│   │   ├── en.ts              # English translations
│   │   └── bn.ts              # Bangla translations
│   │
│   └── utils/              # Utilities
│       ├── cn.ts              # Tailwind class merge
│       └── api.ts             # API client & data management
│
└── server/                 # Backend source
    ├── index.js            # Express server entry
    ├── package.json        # Backend dependencies
    │
    ├── config/
    │   └── database.js     # MongoDB connection
    │
    ├── middleware/
    │   ├── auth.js         # JWT authentication
    │   ├── rateLimit.js    # Rate limiting
    │   └── validateUrl.js  # URL validation
    │
    ├── models/             # MongoDB schemas
    │   ├── User.js
    │   ├── History.js
    │   └── Favorite.js
    │
    ├── platforms/          # Platform handlers
    │   ├── index.js        # Platform detection
    │   ├── youtube.js
    │   ├── tiktok.js
    │   ├── instagram.js
    │   ├── facebook.js
    │   └── twitter.js
    │
    └── routes/             # API routes
        ├── video.js
        ├── auth.js
        ├── history.js
        └── favorites.js
```

## API Endpoints

### Video Processing
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/video/info` | Get video metadata |
| GET | `/api/video/download/:id/:quality` | Get download link |
| POST | `/api/video/track` | Track download |

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/signup` | Create account |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Get current user |

### History (requires auth)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/history` | Get download history |
| POST | `/api/history` | Add to history |
| DELETE | `/api/history` | Clear history |
| DELETE | `/api/history/:id` | Remove item |

### Favorites (requires auth)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/favorites` | Get favorites |
| POST | `/api/favorites` | Add to favorites |
| DELETE | `/api/favorites/:videoId` | Remove from favorites |
| GET | `/api/favorites/check/:videoId` | Check favorite status |

## License

This project is for educational purposes. Respect copyright laws and terms of service of the respective platforms.

---

Built with ❤️ using React, Tailwind CSS, and Node.js
