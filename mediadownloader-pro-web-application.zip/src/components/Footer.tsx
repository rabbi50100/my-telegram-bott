import { useLanguage } from '@/context/LanguageContext';
import { Download, Shield, Zap } from 'lucide-react';

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="mt-auto border-t border-white/5">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-accent">
                <Download className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-bold text-white">
                Media<span className="text-primary-400">Downloader</span>
                <span className="ml-0.5 text-xs text-accent">Pro</span>
              </span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-gray-500">
              {t('app.tagline')}
            </p>
          </div>

          {/* Features */}
          <div>
            <h3 className="mb-3 text-sm font-semibold text-white">Features</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-sm text-gray-400">
                <Zap className="h-3.5 w-3.5 text-primary-400" />
                Fast Downloads
              </li>
              <li className="flex items-center gap-2 text-sm text-gray-400">
                <Shield className="h-3.5 w-3.5 text-accent" />
                Secure & Safe
              </li>
              <li className="flex items-center gap-2 text-sm text-gray-400">
                <Download className="h-3.5 w-3.5 text-primary-400" />
                Multiple Qualities
              </li>
            </ul>
          </div>

          {/* Platforms */}
          <div>
            <h3 className="mb-3 text-sm font-semibold text-white">Supported</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>YouTube</li>
              <li>TikTok</li>
              <li>Instagram</li>
              <li>Facebook</li>
              <li>Twitter / X</li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="mb-3 text-sm font-semibold text-white">Legal</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>Privacy Policy</li>
              <li>Terms of Service</li>
              <li>Copyright Notice</li>
              <li>DMCA</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-white/5 pt-6">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-xs text-gray-500">{t('footer.copyright')}</p>
            <p className="text-xs text-gray-500">{t('footer.disclaimer')}</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
