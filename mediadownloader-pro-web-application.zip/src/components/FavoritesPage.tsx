import { useState, useEffect } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { getFavorites, removeFromFavorite, formatDate, type FavoriteItem } from '@/utils/api';
import { Heart, Trash2, Clock, Globe } from 'lucide-react';
import toast from 'react-hot-toast';

export function FavoritesPage() {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [items, setItems] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    if (isAuthenticated) {
      setItems(getFavorites());
    }
  }, [isAuthenticated]);

  const handleRemove = (item: FavoriteItem) => {
    removeFromFavorite(item.videoId);
    setItems(prev => prev.filter(i => i.videoId !== item.videoId));
    toast.success(t('favorites.removed'));
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-50">
          <Heart className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">Login to see your favorites</h3>
        <p className="mt-1 text-sm text-gray-400">Your favorite videos will appear here</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-50">
          <Heart className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">{t('favorites.empty')}</h3>
        <p className="mt-1 text-sm text-gray-400">Save videos you love by clicking the heart icon</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white">{t('favorites.title')}</h2>
        <p className="text-sm text-gray-400">{items.length} saved</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {items.map((item, index) => (
          <div
            key={item.id}
            className="animate-[fadeIn_0.3s_ease-out] group overflow-hidden rounded-xl border border-white/5 bg-white/[0.02] transition-all hover:border-white/10 hover:bg-white/[0.04]"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            {/* Thumbnail */}
            <div className="relative aspect-video overflow-hidden">
              <img
                src={item.thumbnail}
                alt={item.title}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
              <button
                onClick={() => handleRemove(item)}
                className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-lg bg-black/50 text-gray-400 backdrop-blur-sm transition-all hover:bg-red-500/20 hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </button>
              <div className="absolute bottom-2 left-2 flex items-center gap-1.5 rounded-lg bg-black/60 px-2 py-1 text-xs text-gray-300 backdrop-blur-sm">
                <Globe className="h-3 w-3" />
                {item.platform}
              </div>
            </div>

            {/* Info */}
            <div className="p-4">
              <h3 className="text-sm font-medium text-white line-clamp-2">{item.title}</h3>
              <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                <Clock className="h-3 w-3" />
                {formatDate(item.timestamp)}
              </div>
              <div className="mt-3 flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-red-500/10">
                  <Heart className="h-3.5 w-3.5 fill-current text-red-400" />
                </div>
                <span className="text-xs text-gray-500">Saved to favorites</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
