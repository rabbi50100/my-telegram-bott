import { useState, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Search, Link, AlertCircle, Film, Music2, Globe } from 'lucide-react';
import { cn } from '@/utils/cn';
import { isValidUrl } from '@/utils/api';

interface HeroSectionProps {
  onFetch: (url: string) => void;
  isLoading: boolean;
  error: string | null;
  onClearError: () => void;
}

const platforms = [
  { name: 'YouTube', icon: Film, color: 'text-red-500' },
  { name: 'TikTok', icon: Music2, color: 'text-pink-400' },
  { name: 'Instagram', icon: Globe, color: 'text-purple-400' },
  { name: 'Facebook', icon: Globe, color: 'text-blue-500' },
  { name: 'Twitter/X', icon: Globe, color: 'text-sky-400' },
];

export function HeroSection({ onFetch, isLoading, error, onClearError }: HeroSectionProps) {
  const { t } = useLanguage();
  const [url, setUrl] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUrl = url.trim();

    if (!trimmedUrl) return;

    if (!isValidUrl(trimmedUrl)) {
      onClearError();
      setTimeout(() => onClearError(), 3000);
      return;
    }

    onFetch(trimmedUrl);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
      if (isValidUrl(text.trim())) {
        onFetch(text.trim());
      }
    } catch {
      // Clipboard API not available
    }
  };

  return (
    <section className="relative overflow-hidden py-12 sm:py-20">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-32 -top-32 h-64 w-64 rounded-full bg-primary-500/10 blur-[100px]" />
        <div className="absolute -right-32 -bottom-32 h-64 w-64 rounded-full bg-accent/10 blur-[100px]" />
        <div className="absolute left-1/2 top-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-500/5 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Badge */}
        <div className="mb-6 flex justify-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary-500/20 bg-primary-500/5 px-4 py-1.5 text-xs font-medium text-primary-400">
            <div className="h-1.5 w-1.5 rounded-full bg-primary-400 animate-pulse" />
            Free & Fast Downloads
          </div>
        </div>

        {/* Heading */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Download Any{' '}
            <span className="bg-gradient-to-r from-primary-400 to-accent bg-clip-text text-transparent">
              Video
            </span>
            <br />
            in Seconds
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base text-gray-400 sm:text-lg">
            {t('app.tagline')} — {t('app.subtitle')}
          </p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSubmit} className="mx-auto max-w-2xl">
          <div
            className={cn(
              'group relative flex items-center rounded-2xl border-2 bg-white/5 backdrop-blur-sm transition-all duration-300',
              isFocused
                ? 'border-primary-500/50 bg-primary-500/5 shadow-lg shadow-primary-500/10'
                : 'border-white/10 hover:border-white/20'
            )}
          >
            <div className="flex h-14 items-center pl-5 sm:h-16">
              <Link className={cn('h-5 w-5 transition-colors', isFocused ? 'text-primary-400' : 'text-gray-500')} />
            </div>
            <input
              ref={inputRef}
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder={t('hero.placeholder')}
              className="h-14 flex-1 bg-transparent px-3 text-sm text-white placeholder-gray-500 outline-none sm:h-16 sm:text-base"
              disabled={isLoading}
            />
            <div className="flex items-center gap-1.5 pr-2 sm:pr-3">
              <button
                type="button"
                onClick={handlePaste}
                className="hidden rounded-xl px-3 py-2 text-xs font-medium text-gray-400 transition-colors hover:bg-white/5 hover:text-gray-200 sm:block"
              >
                Paste
              </button>
              <button
                type="submit"
                disabled={isLoading || !url.trim()}
                className={cn(
                  'flex h-10 items-center gap-2 rounded-xl px-5 text-sm font-semibold text-white shadow-lg transition-all sm:h-12 sm:px-6',
                  isLoading || !url.trim()
                    ? 'cursor-not-allowed bg-gray-700'
                    : 'bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-400 hover:to-primary-500 hover:shadow-primary-500/40'
                )}
              >
                {isLoading ? (
                  <>
                    <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span className="hidden sm:inline">{t('hero.button_processing')}</span>
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4" />
                    <span>{t('hero.button')}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* Error Message */}
        {error && (
          <div className="mx-auto mt-4 max-w-2xl animate-[fadeIn_0.3s_ease-out]">
            <div className="flex items-center gap-2.5 rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-400">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          </div>
        )}

        {/* Supported Platforms */}
        <div className="mt-10">
          <p className="mb-4 text-center text-xs font-medium uppercase tracking-wider text-gray-500">
            {t('hero.supported')}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            {platforms.map((platform) => (
              <div
                key={platform.name}
                className="inline-flex items-center gap-2 rounded-xl border border-white/5 bg-white/[0.02] px-4 py-2 text-sm text-gray-400 transition-all hover:border-white/10 hover:text-gray-200"
              >
                <platform.icon className={cn('h-4 w-4', platform.color)} />
                {platform.name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
