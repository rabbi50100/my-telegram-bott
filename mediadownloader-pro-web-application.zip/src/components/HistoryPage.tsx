import { useState, useEffect } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { getHistory, clearHistory, formatDate, type DownloadHistoryItem } from '@/utils/api';
import { History, Trash2, Download, Music, Film, Clock, ExternalLink } from 'lucide-react';
import { cn } from '@/utils/cn';
import toast from 'react-hot-toast';

export function HistoryPage() {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [items, setItems] = useState<DownloadHistoryItem[]>([]);

  useEffect(() => {
    if (isAuthenticated) {
      setItems(getHistory());
    }
  }, [isAuthenticated]);

  const handleClear = () => {
    clearHistory();
    setItems([]);
    toast.success(t('history.deleted'));
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-50">
          <History className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">Login to see your history</h3>
        <p className="mt-1 text-sm text-gray-400">Your downloads will appear here</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-50">
          <History className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-white">{t('history.empty')}</h3>
        <p className="mt-1 text-sm text-gray-400">Start downloading videos to see them here</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">{t('history.title')}</h2>
          <p className="text-sm text-gray-400">{items.length} downloads</p>
        </div>
        <button
          onClick={handleClear}
          className="flex items-center gap-2 rounded-xl border border-red-500/20 bg-red-500/5 px-4 py-2 text-sm font-medium text-red-400 transition-all hover:bg-red-500/10"
        >
          <Trash2 className="h-4 w-4" />
          {t('history.clear')}
        </button>
      </div>

      <div className="space-y-3">
        {items.map((item, index) => (
          <div
            key={item.id}
            className="animate-[fadeIn_0.3s_ease-out] group flex items-center gap-4 rounded-xl border border-white/5 bg-white/[0.02] p-4 transition-all hover:border-white/10 hover:bg-white/[0.04]"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            {/* Thumbnail */}
            <div className="relative h-16 w-24 flex-shrink-0 overflow-hidden rounded-lg sm:h-20 sm:w-32">
              <img
                src={item.thumbnail}
                alt={item.title}
                className="h-full w-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1">
                {item.type === 'audio' ? (
                  <Music className="h-3 w-3 text-accent" />
                ) : (
                  <Film className="h-3 w-3 text-primary-400" />
                )}
              </div>
            </div>

            {/* Info */}
            <div className="min-w-0 flex-1">
              <h3 className="text-sm font-medium text-white line-clamp-1">{item.title}</h3>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <ExternalLink className="h-3 w-3" />
                  {item.platform}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Download className="h-3 w-3" />
                  {item.quality}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatDate(item.timestamp)}
                </span>
              </div>
            </div>

            {/* Type badge */}
            <div className={cn(
              'hidden flex-shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium sm:block',
              item.type === 'audio'
                ? 'bg-accent/10 text-accent'
                : 'bg-primary-500/10 text-primary-400'
            )}>
              {item.type === 'audio' ? 'MP3' : item.quality}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
