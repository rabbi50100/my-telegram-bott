import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import type { VideoInfo, QualityOption } from '@/utils/api';
import { formatDuration, generateDownloadLink, addToHistory, addToFavorite, removeFromFavorite, isFavorite, trackDownload } from '@/utils/api';
import { Clock, Film, Music, Download, Heart, ExternalLink } from 'lucide-react';
import { cn } from '@/utils/cn';
import toast from 'react-hot-toast';

interface VideoCardProps {
  video: VideoInfo;
  onFavoriteChange?: () => void;
}

const platformColors: Record<string, string> = {
  YouTube: 'bg-red-500/10 text-red-400 border-red-500/20',
  TikTok: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
  Instagram: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  Facebook: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  Twitter: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
};

export function VideoCard({ video, onFavoriteChange }: VideoCardProps) {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const [selectedQuality, setSelectedQuality] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [fav, setFav] = useState(() => isFavorite(video.id));

  const handleDownload = async (quality: QualityOption) => {
    if (!isAuthenticated) {
      toast.error('Please login to download');
      return;
    }

    setSelectedQuality(quality.value);
    setIsDownloading(true);

    // Simulate download preparation
    await new Promise(r => setTimeout(r, 1000 + Math.random() * 1500));

    const link = generateDownloadLink(video.id, quality.value, quality.type);
    trackDownload(video.id);

    addToHistory({
      id: 'dl_' + Date.now(),
      videoId: video.id,
      title: video.title,
      thumbnail: video.thumbnail,
      quality: quality.label,
      platform: video.platform,
      timestamp: Date.now(),
      type: quality.type,
    });

    // In a real app, this would trigger the actual download
    window.open(link, '_blank');

    setIsDownloading(false);
    setSelectedQuality(null);
    toast.success(`${video.title.substring(0, 40)}... - ${quality.label}`);
  };

  const toggleFavorite = () => {
    if (!isAuthenticated) {
      toast.error('Please login to add favorites');
      return;
    }

    if (fav) {
      removeFromFavorite(video.id);
      setFav(false);
      toast.success(t('favorites.removed'));
    } else {
      addToFavorite({
        id: 'fav_' + Date.now(),
        videoId: video.id,
        title: video.title,
        thumbnail: video.thumbnail,
        platform: video.platform,
        url: video.url,
        timestamp: Date.now(),
      });
      setFav(true);
      toast.success(t('favorites.added'));
    }
    onFavoriteChange?.();
  };

  const videoQualities = video.qualities.filter(q => q.type === 'video');
  const audioQualities = video.qualities.filter(q => q.type === 'audio');

  return (
    <div className="animate-[fadeIn_0.5s_ease-out] mx-auto max-w-4xl">
      <div className="overflow-hidden rounded-2xl border border-white/10 bg-surface shadow-2xl shadow-black/30">
        <div className="grid gap-0 md:grid-cols-5">
          {/* Thumbnail */}
          <div className="relative md:col-span-2">
            <div className="aspect-video md:aspect-auto md:h-full">
              <img
                src={video.thumbnail}
                alt={video.title}
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            {/* Duration Badge */}
            <div className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-lg bg-black/80 px-2.5 py-1.5 text-xs font-medium text-white backdrop-blur-sm">
              <Clock className="h-3 w-3" />
              {formatDuration(video.duration)}
            </div>
            {/* Platform Badge */}
            <div className="absolute right-3 top-3">
              <span className={cn(
                'inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-medium backdrop-blur-sm',
                platformColors[video.platform] || 'bg-gray-500/10 text-gray-400 border-gray-500/20'
              )}>
                <ExternalLink className="h-3 w-3" />
                {video.platform}
              </span>
            </div>
          </div>

          {/* Info & Downloads */}
          <div className="p-5 md:col-span-3 md:p-6 lg:p-8">
            {/* Title & Favorite */}
            <div className="mb-4 flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <h2 className="text-lg font-bold leading-snug text-white line-clamp-2 sm:text-xl">
                  {video.title}
                </h2>
                <p className="mt-1.5 text-sm text-gray-400">
                  {video.platform} · {formatDuration(video.duration)}
                </p>
              </div>
              <button
                onClick={toggleFavorite}
                className={cn(
                  'flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl border transition-all',
                  fav
                    ? 'border-red-500/30 bg-red-500/10 text-red-400'
                    : 'border-white/10 text-gray-500 hover:border-white/20 hover:text-gray-300'
                )}
              >
                <Heart className={cn('h-4 w-4', fav && 'fill-current')} />
              </button>
            </div>

            {/* Video Qualities */}
            <div className="mb-4">
              <div className="mb-2.5 flex items-center gap-2 text-sm font-medium text-gray-300">
                <Film className="h-4 w-4 text-primary-400" />
                {t('video.download_video')}
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {videoQualities.map((q) => (
                  <button
                    key={q.value}
                    onClick={() => handleDownload(q)}
                    disabled={isDownloading}
                    className={cn(
                      'group relative overflow-hidden rounded-xl border p-3 text-left transition-all duration-200',
                      isDownloading && selectedQuality === q.value
                        ? 'border-primary-500/50 bg-primary-500/10'
                        : 'border-white/5 bg-white/[0.02] hover:border-primary-500/30 hover:bg-primary-500/5'
                    )}
                  >
                    {isDownloading && selectedQuality === q.value && (
                      <div className="absolute inset-0 animate-shimmer" />
                    )}
                    <div className="relative">
                      <div className="text-sm font-semibold text-white">{q.label}</div>
                      <div className="mt-0.5 text-xs text-gray-500">{q.size}</div>
                    </div>
                    {isDownloading && selectedQuality === q.value ? (
                      <div className="relative mt-2 flex items-center justify-center">
                        <svg className="h-4 w-4 animate-spin text-primary-400" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                      </div>
                    ) : (
                      <div className="relative mt-2 flex items-center gap-1 text-xs text-primary-400 opacity-0 transition-opacity group-hover:opacity-100">
                        <Download className="h-3 w-3" />
                        Download
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Quality */}
            {audioQualities.length > 0 && (
              <div>
                <div className="mb-2.5 flex items-center gap-2 text-sm font-medium text-gray-300">
                  <Music className="h-4 w-4 text-accent" />
                  {t('video.download_audio')}
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {audioQualities.map((q) => (
                    <button
                      key={q.value}
                      onClick={() => handleDownload(q)}
                      disabled={isDownloading}
                      className={cn(
                        'group relative overflow-hidden rounded-xl border p-3 text-left transition-all duration-200',
                        isDownloading && selectedQuality === q.value
                          ? 'border-accent/50 bg-accent/10'
                          : 'border-white/5 bg-white/[0.02] hover:border-accent/30 hover:bg-accent/5'
                      )}
                    >
                      {isDownloading && selectedQuality === q.value && (
                        <div className="absolute inset-0 animate-shimmer" />
                      )}
                      <div className="relative">
                        <div className="text-sm font-semibold text-white">{q.label}</div>
                        <div className="mt-0.5 text-xs text-gray-500">{q.size}</div>
                      </div>
                      {isDownloading && selectedQuality === q.value ? (
                        <div className="relative mt-2 flex items-center justify-center">
                          <svg className="h-4 w-4 animate-spin text-accent" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                        </div>
                      ) : (
                        <div className="relative mt-2 flex items-center gap-1 text-xs text-accent opacity-0 transition-opacity group-hover:opacity-100">
                          <Download className="h-3 w-3" />
                          Download
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
