import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { AuthModal } from './AuthModal';
import { getLanguages } from '@/i18n';
import { Download, History, Heart, Home, LogIn, LogOut, Globe, Menu, X, User } from 'lucide-react';
import { cn } from '@/utils/cn';

interface HeaderProps {
  currentPage: 'home' | 'history' | 'favorites';
  onNavigate: (page: 'home' | 'history' | 'favorites') => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const { t, lang, setLang } = useLanguage();
  const { isAuthenticated, user, logout } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const navItems = [
    { key: 'home', icon: Home, label: 'nav.home' },
    { key: 'history', icon: History, label: 'nav.history' },
    { key: 'favorites', icon: Heart, label: 'nav.favorites' },
  ] as const;

  const handleNav = (page: 'home' | 'history' | 'favorites') => {
    onNavigate(page);
    setShowMobileMenu(false);
  };

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-white/5 bg-surface/80 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <button
              onClick={() => handleNav('home')}
              className="flex items-center gap-2.5 transition-opacity hover:opacity-80"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent shadow-lg">
                <Download className="h-5 w-5 text-white" />
              </div>
              <span className="hidden text-lg font-bold text-white sm:block">
                Media<span className="text-primary-400">Downloader</span>
                <span className="ml-0.5 text-xs font-medium text-accent">Pro</span>
              </span>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden items-center gap-1 md:flex">
              {navItems.map((item) => (
                <button
                  key={item.key}
                  onClick={() => handleNav(item.key)}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all duration-200',
                    currentPage === item.key
                      ? 'bg-primary-500/10 text-primary-400 shadow-sm'
                      : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {t(item.label)}
                </button>
              ))}
            </nav>

            {/* Right side */}
            <div className="flex items-center gap-2">
              {/* Language Switcher */}
              <div className="relative">
                <button
                  onClick={() => setShowLangMenu(!showLangMenu)}
                  className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-gray-400 transition-all hover:bg-white/5 hover:text-gray-200"
                >
                  <Globe className="h-4 w-4" />
                  <span className="hidden sm:inline">{lang.toUpperCase()}</span>
                </button>
                {showLangMenu && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowLangMenu(false)} />
                    <div className="absolute right-0 top-full mt-1 z-50 w-36 overflow-hidden rounded-xl border border-white/10 bg-surface-50 p-1 shadow-2xl shadow-black/50">
                      {getLanguages().map((l) => (
                        <button
                          key={l.code}
                          onClick={() => {
                            setLang(l.code);
                            setShowLangMenu(false);
                          }}
                          className={cn(
                            'flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors',
                            lang === l.code
                              ? 'bg-primary-500/10 text-primary-400'
                              : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'
                          )}
                        >
                          {l.name}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Auth Button */}
              {isAuthenticated ? (
                <div className="relative group">
                  <button className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-gray-400 transition-all hover:bg-white/5 hover:text-gray-200">
                    <User className="h-4 w-4" />
                    <span className="hidden sm:inline">{user?.name}</span>
                  </button>
                  <div className="absolute right-0 top-full mt-1 hidden group-hover:block z-50">
                    <div className="w-48 overflow-hidden rounded-xl border border-white/10 bg-surface-50 p-1 shadow-2xl shadow-black/50">
                      <button
                        onClick={logout}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-400 transition-colors hover:bg-red-500/10 hover:text-red-400"
                      >
                        <LogOut className="h-4 w-4" />
                        {t('auth.logout')}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowAuth(true)}
                  className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-primary-500 to-primary-600 px-4 py-2 text-sm font-medium text-white shadow-lg shadow-primary-500/25 transition-all hover:from-primary-400 hover:to-primary-500 hover:shadow-primary-500/40"
                >
                  <LogIn className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('auth.login')}</span>
                </button>
              )}

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="ml-1 flex items-center justify-center rounded-lg p-2 text-gray-400 transition-colors hover:bg-white/5 hover:text-gray-200 md:hidden"
              >
                {showMobileMenu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {showMobileMenu && (
          <div className="border-t border-white/5 md:hidden">
            <div className="space-y-1 px-4 pb-4 pt-2">
              {navItems.map((item) => (
                <button
                  key={item.key}
                  onClick={() => handleNav(item.key)}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all',
                    currentPage === item.key
                      ? 'bg-primary-500/10 text-primary-400'
                      : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {t(item.label)}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </>
  );
}
