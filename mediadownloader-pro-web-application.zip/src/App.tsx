import { useState, useCallback } from 'react';
import { Toaster } from 'react-hot-toast';
import { LanguageProvider } from '@/context/LanguageContext';
import { AuthProvider } from '@/context/AuthContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { HeroSection } from '@/components/HeroSection';
import { VideoCard } from '@/components/VideoCard';
import { HistoryPage } from '@/components/HistoryPage';
import { FavoritesPage } from '@/components/FavoritesPage';
import { fetchVideoInfo, isValidUrl, type VideoInfo } from '@/utils/api';
import { useLanguage } from '@/context/LanguageContext';

function AppContent() {
  const { t } = useLanguage();
  const [currentPage, setCurrentPage] = useState<'home' | 'history' | 'favorites'>('home');
  const [video, setVideo] = useState<VideoInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [favoriteKey, setFavoriteKey] = useState(0);

  const handleFetchVideo = useCallback(async (url: string) => {
    const trimmedUrl = url.trim();

    if (!isValidUrl(trimmedUrl)) {
      setError(t('errors.invalid_url'));
      setVideo(null);
      return;
    }

    setIsLoading(true);
    setError(null);
    setVideo(null);

    try {
      const info = await fetchVideoInfo(trimmedUrl);
      setVideo(info);
    } catch (err: any) {
      const message = err?.message === 'unsupported'
        ? t('errors.unsupported')
        : t('errors.network');
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, [t]);

  const handleClearError = useCallback(() => {
    setError(null);
  }, []);

  const handleFavoriteChange = useCallback(() => {
    setFavoriteKey(prev => prev + 1);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'history':
        return <HistoryPage />;
      case 'favorites':
        return <FavoritesPage key={favoriteKey} />;
      default:
        return (
          <main>
            <HeroSection
              onFetch={handleFetchVideo}
              isLoading={isLoading}
              error={error}
              onClearError={handleClearError}
            />

            {/* Loading Indicator */}
            {isLoading && (
              <div className="mx-auto mt-8 max-w-4xl px-4 sm:px-6 lg:px-8">
                <div className="overflow-hidden rounded-2xl border border-white/10 bg-surface shadow-2xl shadow-black/30">
                  <div className="grid gap-0 md:grid-cols-5">
                    <div className="md:col-span-2">
                      <div className="aspect-video animate-pulse bg-surface-100 md:aspect-auto md:h-full" />
                    </div>
                    <div className="p-6 md:col-span-3 lg:p-8">
                      <div className="space-y-4">
                        <div className="h-6 w-3/4 animate-pulse rounded-lg bg-surface-100" />
                        <div className="h-4 w-1/3 animate-pulse rounded-lg bg-surface-100" />
                        <div className="grid grid-cols-3 gap-3">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="h-20 animate-pulse rounded-xl bg-surface-100" />
                          ))}
                        </div>
                        <div className="h-4 w-1/4 animate-pulse rounded-lg bg-surface-100" />
                        <div className="grid grid-cols-3 gap-3">
                          {[1].map((i) => (
                            <div key={i} className="h-20 animate-pulse rounded-xl bg-surface-100" />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Video Result */}
            {video && !isLoading && (
              <div className="mt-8 pb-12">
                <VideoCard
                  video={video}
                  onFavoriteChange={handleFavoriteChange}
                />
              </div>
            )}
          </main>
        );
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />
      {renderPage()}
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#1e293b',
              color: '#e2e8f0',
              border: '1px solid rgba(255,255,255,0.05)',
              borderRadius: '12px',
              fontSize: '14px',
            },
            success: {
              iconTheme: {
                primary: '#6366f1',
                secondary: '#1e293b',
              },
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#1e293b',
              },
            },
          }}
        />
        <AppContent />
      </LanguageProvider>
    </AuthProvider>
  );
}
