export interface VideoInfo {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
  platform: string;
  url: string;
  qualities: QualityOption[];
}

export interface QualityOption {
  label: string;
  value: string;
  size: string;
  type: 'video' | 'audio';
}

export interface DownloadHistoryItem {
  id: string;
  videoId: string;
  title: string;
  thumbnail: string;
  quality: string;
  platform: string;
  timestamp: number;
  type: 'video' | 'audio';
}

export interface FavoriteItem {
  id: string;
  videoId: string;
  title: string;
  thumbnail: string;
  platform: string;
  url: string;
  timestamp: number;
}

// Mock platform detection
function detectPlatform(url: string): string {
  const patterns: Record<string, RegExp> = {
    youtube: /(?:youtube\.com|youtu\.be)/i,
    tiktok: /tiktok\.com/i,
    instagram: /instagram\.com/i,
    facebook: /facebook\.com|fb\.watch/i,
    twitter: /twitter\.com|x\.com/i,
  };

  for (const [platform, pattern] of Object.entries(patterns)) {
    if (pattern.test(url)) return platform;
  }
  return 'unknown';
}

// Mock video info fetching
export async function fetchVideoInfo(url: string): Promise<VideoInfo> {
  const platform = detectPlatform(url);

  if (platform === 'unknown') {
    throw new Error('unsupported');
  }

  // Simulate network delay
  await new Promise(r => setTimeout(r, 1500 + Math.random() * 1000));

  // Mock response
  const mockVideos: Record<string, Partial<VideoInfo>> = {
    youtube: {
      id: 'yt_' + Math.random().toString(36).substr(2, 11),
      title: 'How to Build a Full Stack Web Application | Complete Tutorial 2026',
      thumbnail: `https://picsum.photos/seed/${Date.now()}/1280/720`,
      duration: 1847,
      platform: 'YouTube',
      qualities: [
        { label: '144p (Low)', value: '144', size: '~15 MB', type: 'video' },
        { label: '360p', value: '360', size: '~45 MB', type: 'video' },
        { label: '480p', value: '480', size: '~80 MB', type: 'video' },
        { label: '720p (HD)', value: '720', size: '~150 MB', type: 'video' },
        { label: '1080p (Full HD)', value: '1080', size: '~280 MB', type: 'video' },
        { label: 'MP3 Audio', value: 'mp3', size: '~8 MB', type: 'audio' },
      ],
    },
    tiktok: {
      id: 'tt_' + Math.random().toString(36).substr(2, 11),
      title: 'This viral dance trend is taking over! #dance #viral #trending',
      thumbnail: `https://picsum.photos/seed/${Date.now() + 1}/720/1280`,
      duration: 34,
      platform: 'TikTok',
      qualities: [
        { label: '360p', value: '360', size: '~5 MB', type: 'video' },
        { label: '720p (HD)', value: '720', size: '~12 MB', type: 'video' },
        { label: 'MP3 Audio', value: 'mp3', size: '~2 MB', type: 'audio' },
      ],
    },
    instagram: {
      id: 'ig_' + Math.random().toString(36).substr(2, 11),
      title: 'Beautiful sunset views from the rooftop 🌅 #travel #photography',
      thumbnail: `https://picsum.photos/seed/${Date.now() + 2}/1080/1080`,
      duration: 58,
      platform: 'Instagram',
      qualities: [
        { label: '360p', value: '360', size: '~4 MB', type: 'video' },
        { label: '720p (HD)', value: '720', size: '~10 MB', type: 'video' },
        { label: 'MP3 Audio', value: 'mp3', size: '~1.5 MB', type: 'audio' },
      ],
    },
    facebook: {
      id: 'fb_' + Math.random().toString(36).substr(2, 11),
      title: 'Live: Community Event Highlights | Annual Festival 2026',
      thumbnail: `https://picsum.photos/seed/${Date.now() + 3}/1280/720`,
      duration: 3600,
      platform: 'Facebook',
      qualities: [
        { label: '360p', value: '360', size: '~30 MB', type: 'video' },
        { label: '720p (HD)', value: '720', size: '~90 MB', type: 'video' },
        { label: '1080p (Full HD)', value: '1080', size: '~180 MB', type: 'video' },
        { label: 'MP3 Audio', value: 'mp3', size: '~10 MB', type: 'audio' },
      ],
    },
    twitter: {
      id: 'tw_' + Math.random().toString(36).substr(2, 11),
      title: 'Breaking: Major announcement from the tech conference keynote 🚀',
      thumbnail: `https://picsum.photos/seed/${Date.now() + 4}/1280/720`,
      duration: 142,
      platform: 'Twitter',
      qualities: [
        { label: '360p', value: '360', size: '~6 MB', type: 'video' },
        { label: '720p (HD)', value: '720', size: '~15 MB', type: 'video' },
        { label: 'MP3 Audio', value: 'mp3', size: '~3 MB', type: 'audio' },
      ],
    },
  };

  const mock = mockVideos[platform] || mockVideos.youtube!;

  return {
    url,
    ...mock,
  } as VideoInfo;
}

// Validate URL format
export function isValidUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol);
  } catch {
    return false;
  }
}

// Generate download link (simulated)
export function generateDownloadLink(videoId: string, quality: string, type: 'video' | 'audio'): string {
  const ext = type === 'audio' ? 'mp3' : 'mp4';
  return `https://cdn.mediadownloader.pro/download/${videoId}/${quality}.${ext}?token=mock_token_${Date.now()}`;
}

// Simulate download count tracking
const downloadCounts = new Map<string, number>();

export function trackDownload(videoId: string): number {
  const count = (downloadCounts.get(videoId) || 0) + 1;
  downloadCounts.set(videoId, count);
  return count;
}

// History management
export function getHistory(): DownloadHistoryItem[] {
  try {
    const stored = localStorage.getItem('mdp_history');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function addToHistory(item: DownloadHistoryItem): void {
  const history = getHistory();
  history.unshift(item);
  localStorage.setItem('mdp_history', JSON.stringify(history.slice(0, 50))); // Keep last 50
}

export function clearHistory(): void {
  localStorage.removeItem('mdp_history');
}

// Favorites management
export function getFavorites(): FavoriteItem[] {
  try {
    const stored = localStorage.getItem('mdp_favorites');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export function addToFavorite(item: FavoriteItem): void {
  const favorites = getFavorites();
  if (!favorites.some(f => f.videoId === item.videoId)) {
    favorites.unshift(item);
    localStorage.setItem('mdp_favorites', JSON.stringify(favorites));
  }
}

export function removeFromFavorite(videoId: string): void {
  const favorites = getFavorites().filter(f => f.videoId !== videoId);
  localStorage.setItem('mdp_favorites', JSON.stringify(favorites));
}

export function isFavorite(videoId: string): boolean {
  return getFavorites().some(f => f.videoId === videoId);
}

// Format duration
export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m}:${s.toString().padStart(2, '0')}`;
}

// Format date
export function formatDate(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days} days ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
