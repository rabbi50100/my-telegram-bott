import { en } from './en';
import { bn } from './bn';

export type Language = 'en' | 'bn';
export type TranslationKey = string;

const translations: Record<Language, Record<string, Record<string, string>>> = {
  en: en as Record<string, Record<string, string>>,
  bn: bn,
};

export function t(key: string, lang: Language, params?: Record<string, string>): string {
  const keys = key.split('.');
  let value: any = translations[lang];

  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      // Fallback to English
      let fallback: any = translations['en'];
      for (const fk of keys) {
        if (fallback && typeof fallback === 'object' && fk in fallback) {
          fallback = fallback[fk];
        } else {
          return key;
        }
      }
      value = fallback;
      break;
    }
  }

  if (typeof value !== 'string') return key;

  if (params) {
    let result = value;
    for (const [paramKey, paramValue] of Object.entries(params)) {
      result = result.replace(`{${paramKey}}`, paramValue);
    }
    return result;
  }

  return value;
}

export function getLanguages(): { code: Language; name: string }[] {
  return [
    { code: 'en', name: en.language?.en || 'English' },
    { code: 'bn', name: bn.language?.bn || 'বাংলা' },
  ];
}
